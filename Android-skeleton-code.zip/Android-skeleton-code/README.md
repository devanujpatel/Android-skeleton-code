# Android-skeleton-code
Template for empty android project. Starting point for building on top.
